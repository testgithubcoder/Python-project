# ⚠ ***IMPORTANT POINTS:*** ⚠

- *If you want to fix a lot of Issues together, please consider opening a Draft PR first and mention alL the issues in a list along with the status of the fix that you are working on.*
- *Mention the `IssueNumber` in your PR if it is fixing an Issue.*
- *After your PR gets reviewed, put `closes #IssueNumber` to automatically close the Issue related with your PR.*
- *A big change should be first discussed by opening an Issue.*
- *Please provide sufficient information regarding the changes you have made.*

[comment]: <> (Please remove all the above points and this message while creating the PR.)