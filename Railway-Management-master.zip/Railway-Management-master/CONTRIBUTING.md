# Contributing Guide

## If you want to CONTRIBUTE to the project you can do so by creating a branch and opening a Pull Request.
